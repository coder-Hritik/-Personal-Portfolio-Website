'use client'

import { useEffect, useRef, useState } from 'react'

type SkillCategory = {
  title: string
  skills: { name: string; level: number }[]
}

const skillCategories: SkillCategory[] = [
  {
    title: 'Languages',
    skills: [
      { name: 'Java', level: 85 },
      { name: 'JavaScript', level: 80 },
      { name: 'C', level: 75 },
      { name: 'C++', level: 70 },
      { name: 'HTML', level: 95 },
      { name: 'CSS', level: 90 },
    ],
  },
  {
    title: 'Frameworks & Tools',
    skills: [
      { name: 'React.js', level: 80 },
      { name: 'Node.js', level: 70 },
      { name: 'Redux', level: 65 },
      { name: 'Git & GitHub', level: 85 },
      { name: 'Bootstrap', level: 85 },
    ],
  },
  {
    title: 'Database',
    skills: [
      { name: 'MySQL', level: 80 },
      { name: 'MongoDB', level: 70 },
    ],
  },
]

function SkillBar({ name, level, isVisible, delay }: { name: string; level: number; isVisible: boolean; delay: number }) {
  const [width, setWidth] = useState(0)

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setWidth(level)
      }, delay)
      return () => clearTimeout(timer)
    }
  }, [isVisible, level, delay])

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium text-foreground">{name}</span>
        <span className="text-sm text-muted-foreground">{level}%</span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  )
}

export function Skills() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="skills"
      className="py-20 sm:py-32 bg-secondary/30 relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <h2 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
            My Skills
          </h2>
          <h3 className="text-3xl sm:text-4xl font-bold">
            Technical{' '}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Expertise
            </span>
          </h3>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            A comprehensive overview of my technical skills and proficiency levels across different technologies and tools.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {skillCategories.map((category, categoryIndex) => (
            <div
              key={category.title}
              className={`bg-card rounded-2xl p-6 border border-border ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${200 + categoryIndex * 100}ms` }}
            >
              <h4 className="text-lg font-semibold text-foreground mb-6 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-gradient-to-r from-primary to-accent" />
                {category.title}
              </h4>
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <SkillBar
                    key={skill.name}
                    name={skill.name}
                    level={skill.level}
                    isVisible={isVisible}
                    delay={400 + categoryIndex * 100 + skillIndex * 100}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
