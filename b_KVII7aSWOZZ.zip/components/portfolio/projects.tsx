'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, ChevronRight, ExternalLink, Github } from 'lucide-react'

type Project = {
  id: number
  title: string
  description: string
  features: string[]
  techStack: string[]
  images: string[]
  imageLabels: string[]
}

const projects: Project[] = [
  {
    id: 1,
    title: 'Library Management System',
    description: 'A comprehensive web-based system to manage books, users, and issue/return operations efficiently. The system streamlines library operations with an intuitive interface for both administrators and students.',
    features: [
      'Admin & Student login with role-based access',
      'Book issue and return functionality',
      'Advanced search functionality',
      'Member management system',
      'Real-time book availability tracking',
    ],
    techStack: ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
    images: [
      '/projects/library-management/1.png',
      '/projects/library-management/2.png',
      '/projects/library-management/3.png',
      '/projects/library-management/4.png',
      '/projects/library-management/5.png',
      '/projects/library-management/6.png',
    ],
    imageLabels: ['Login Page', 'Admin Dashboard', 'User Dashboard', 'Add Book', 'Manage Books', 'Issue Book'],
  },
  {
    id: 2,
    title: 'Covid Vaccination Management System',
    description: 'A robust system for managing vaccination booking and tracking. Built to help streamline the vaccination process during the pandemic with efficient scheduling and certificate generation.',
    features: [
      'User and Admin modules',
      'Vaccination booking system',
      'Certificate generation',
      'Appointment scheduling',
      'Vaccination status tracking',
    ],
    techStack: ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS'],
    images: [
      '/projects/covid-vaccination/1.png',
      '/projects/covid-vaccination/2.png',
      '/projects/covid-vaccination/3.png',
      '/projects/covid-vaccination/4.png',
      '/projects/covid-vaccination/5.png',
    ],
    imageLabels: ['Home Page', 'Admin Dashboard', 'New Booking', 'Vaccination History', 'Vaccination Report'],
  },
]

function ProjectCard({ project, onOpenModal, isVisible, delay }: { project: Project; onOpenModal: () => void; isVisible: boolean; delay: number }) {
  return (
    <div
      className={`group bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 ${
        isVisible ? 'animate-fade-in-up' : 'opacity-0'
      }`}
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Project Image */}
      <div className="aspect-video bg-muted relative overflow-hidden">
        <Image
          src={project.images[0]}
          alt={project.title}
          fill
          className="object-cover object-top group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        <h4 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
          {project.title}
        </h4>
        <p className="text-muted-foreground text-sm line-clamp-2">
          {project.description}
        </p>

        {/* Tech Stack */}
        <div className="flex flex-wrap gap-2">
          {project.techStack.slice(0, 4).map((tech) => (
            <Badge key={tech} variant="secondary" className="text-xs">
              {tech}
            </Badge>
          ))}
          {project.techStack.length > 4 && (
            <Badge variant="secondary" className="text-xs">
              +{project.techStack.length - 4}
            </Badge>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 border-primary/50 hover:bg-primary/10"
            onClick={onOpenModal}
          >
            View Details
          </Button>
          <Button variant="ghost" size="icon" className="shrink-0">
            <Github className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

function ProjectModal({ project, isOpen, onClose }: { project: Project | null; isOpen: boolean; onClose: () => void }) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  // Reset image index when project changes
  useEffect(() => {
    setCurrentImageIndex(0)
  }, [project])

  if (!project) return null

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % project.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + project.images.length) % project.images.length)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{project.title}</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            {project.description}
          </DialogDescription>
        </DialogHeader>

        {/* Image Gallery */}
        <div className="relative aspect-video bg-muted rounded-lg overflow-hidden my-4">
          <Image
            src={project.images[currentImageIndex]}
            alt={`${project.title} - ${project.imageLabels[currentImageIndex]}`}
            fill
            className="object-contain"
          />
          
          {/* Image Label */}
          <div className="absolute top-4 left-4 px-3 py-1 bg-background/90 rounded-full text-sm font-medium">
            {project.imageLabels[currentImageIndex]}
          </div>
          
          {/* Navigation Arrows */}
          {project.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/80 hover:bg-background transition-colors z-10"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/80 hover:bg-background transition-colors z-10"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}

          {/* Image Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {project.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  index === currentImageIndex ? 'bg-primary' : 'bg-muted-foreground/50'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Features */}
        <div className="space-y-3">
          <h5 className="font-semibold text-foreground">Key Features</h5>
          <ul className="space-y-2">
            {project.features.map((feature, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {/* Tech Stack */}
        <div className="space-y-3">
          <h5 className="font-semibold text-foreground">Tech Stack</h5>
          <div className="flex flex-wrap gap-2">
            {project.techStack.map((tech) => (
              <Badge key={tech} className="bg-gradient-to-r from-primary/20 to-accent/20 text-foreground border-0">
                {tech}
              </Badge>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-4">
          <Button className="flex-1 bg-gradient-to-r from-primary to-accent hover:opacity-90">
            <ExternalLink className="mr-2 h-4 w-4" />
            Live Demo
          </Button>
          <Button variant="outline" className="flex-1">
            <Github className="mr-2 h-4 w-4" />
            View Code
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export function Projects() {
  const [isVisible, setIsVisible] = useState(false)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const openModal = (project: Project) => {
    setSelectedProject(project)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setSelectedProject(null)
  }

  return (
    <section
      ref={sectionRef}
      id="projects"
      className="py-20 sm:py-32 relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <h2 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
            My Work
          </h2>
          <h3 className="text-3xl sm:text-4xl font-bold">
            Featured{' '}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Projects
            </span>
          </h3>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            A showcase of my recent projects demonstrating my skills in web development and problem-solving.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.id}
              project={project}
              onOpenModal={() => openModal(project)}
              isVisible={isVisible}
              delay={200 + index * 150}
            />
          ))}
        </div>
      </div>

      {/* Project Modal */}
      <ProjectModal project={selectedProject} isOpen={isModalOpen} onClose={closeModal} />
    </section>
  )
}
