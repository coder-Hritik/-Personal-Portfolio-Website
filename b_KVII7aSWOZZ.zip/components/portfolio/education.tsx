'use client'

import { useEffect, useRef, useState } from 'react'
import { GraduationCap, Calendar } from 'lucide-react'

type Education = {
  degree: string
  institution: string
  period: string
  description: string
}

const educationData: Education[] = [
  {
    degree: 'Master of Computer Applications (MCA)',
    institution: 'JNCT Professional University',
    period: '2024 - 2026',
    description: 'Currently pursuing MCA with focus on advanced software development, data structures, algorithms, and modern web technologies.',
  },
  {
    degree: 'Bachelor of Computer Applications (BCA)',
    institution: 'Makhanlal Chaturvedi University',
    period: '2020 - 2023',
    description: 'Completed BCA with strong foundation in programming, database management, and web development fundamentals.',
  },
]

export function Education() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="education"
      className="py-20 sm:py-32 bg-secondary/30 relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <h2 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
            Education
          </h2>
          <h3 className="text-3xl sm:text-4xl font-bold">
            Academic{' '}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Journey
            </span>
          </h3>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            My educational background that has shaped my skills and knowledge in computer science and software development.
          </p>
        </div>

        {/* Timeline */}
        <div className="max-w-3xl mx-auto relative">
          {/* Timeline Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-accent to-primary/20" />

          {/* Education Items */}
          <div className="space-y-12">
            {educationData.map((edu, index) => (
              <div
                key={edu.degree}
                className={`relative ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}
                style={{ animationDelay: `${200 + index * 150}ms` }}
              >
                <div className={`flex flex-col md:flex-row items-start gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                  {/* Timeline Dot */}
                  <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gradient-to-r from-primary to-accent border-4 border-background z-10" />

                  {/* Content Card */}
                  <div className={`ml-16 md:ml-0 md:w-[calc(50%-2rem)] ${index % 2 === 0 ? 'md:pr-8 md:text-right' : 'md:pl-8'}`}>
                    <div className="bg-card rounded-2xl p-6 border border-border hover:border-primary/50 transition-colors group">
                      <div className={`flex items-center gap-2 mb-3 ${index % 2 === 0 ? 'md:justify-end' : ''}`}>
                        <Calendar className="h-4 w-4 text-primary" />
                        <span className="text-sm text-primary font-medium">{edu.period}</span>
                      </div>
                      
                      <div className={`flex items-start gap-3 mb-3 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                          <GraduationCap className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground text-lg">{edu.degree}</h4>
                          <p className="text-sm text-muted-foreground">{edu.institution}</p>
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {edu.description}
                      </p>
                    </div>
                  </div>

                  {/* Spacer for alternating layout */}
                  <div className="hidden md:block md:w-[calc(50%-2rem)]" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
