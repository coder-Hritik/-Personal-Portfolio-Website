'use client'

import { useEffect, useRef, useState } from 'react'
import { Code2, Lightbulb, Rocket, Users } from 'lucide-react'

const highlights = [
  {
    icon: Code2,
    title: 'Clean Code',
    description: 'Writing maintainable and scalable code',
  },
  {
    icon: Lightbulb,
    title: 'Problem Solver',
    description: 'Creative solutions to complex challenges',
  },
  {
    icon: Rocket,
    title: 'Fast Learner',
    description: 'Quickly adapting to new technologies',
  },
  {
    icon: Users,
    title: 'Team Player',
    description: 'Collaborative and communicative',
  },
]

export function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="about"
      className="py-20 sm:py-32 relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className={`text-center mb-16 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <h2 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
              About Me
            </h2>
            <h3 className="text-3xl sm:text-4xl font-bold">
              Passionate About Building{' '}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Digital Solutions
              </span>
            </h3>
          </div>

          {/* About Content */}
          <div className={`space-y-8 ${isVisible ? 'animate-fade-in-up animation-delay-200' : 'opacity-0'}`}>
            <div className="bg-card rounded-2xl p-8 border border-border">
              <p className="text-lg text-muted-foreground leading-relaxed">
                I am a passionate MCA student with a strong interest in web development and software engineering. 
                My journey in technology started with curiosity about how applications work, which has evolved into 
                a deep commitment to building practical, scalable, and user-friendly solutions.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mt-4">
                With a solid foundation in programming languages like Java, JavaScript, and modern frameworks like 
                React.js and Node.js, I enjoy tackling complex problems and transforming ideas into functional 
                applications. I am constantly learning and exploring new technologies to stay updated with industry 
                trends and best practices.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mt-4">
                When I&apos;m not coding, you&apos;ll find me exploring new technologies, contributing to open-source projects, 
                or working on personal projects that challenge my skills and help me grow as a developer.
              </p>
            </div>

            {/* Highlights Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {highlights.map((item, index) => (
                <div
                  key={item.title}
                  className={`bg-card rounded-xl p-6 border border-border hover:border-primary/50 transition-all duration-300 group ${
                    isVisible ? `animate-fade-in-up` : 'opacity-0'
                  }`}
                  style={{ animationDelay: `${300 + index * 100}ms` }}
                >
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="font-semibold text-foreground mb-1">{item.title}</h4>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
